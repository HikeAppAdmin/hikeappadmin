HIKE+ — Pack France randonnées courtes + boucles

Base conservée intégralement : 126 GPX du pack V4.
Ajout : randonnées supplémentaires détectées comme boucles (départ/arrivée <= 150 m) parmi les GPX déjà disponibles dans HIKE+.
Aucun fichier existant du pack V4 n'a été modifié ou supprimé.

Les données ajoutées sont réelles. La détection de boucle est géométrique.
