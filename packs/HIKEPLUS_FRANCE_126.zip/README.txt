HIKE+ — PACK 126 RANDONNÉES COURTES

126 itinéraires réels extraits du KML national OpenStreetMap fourni.
Sélection : itinéraires nommés, distance source <= 35 km, avec diversité géographique.
Distance maximale du pack : 30,5 km.
Les fichiers GPX contiennent le tracé réel présent dans la source KML.

Le pack remplace le précédent pack de 126 itinéraires trop longs.
