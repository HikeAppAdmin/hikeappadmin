HIKE+ — 126 GPX RÉELS
=======================

Ces 126 fichiers GPX ont été extraits directement du fichier KML national
fourni dans cette conversation : magosm-hiking_foot_routes_line.kml.

Source des géométries : données OpenStreetMap diffusées par Magellium / data.gouv.fr.
Les noms placés dans <metadata><name> et <trk><name> sont les noms réels présents
dans les données sources. Aucun tracé GPS n'a été inventé.

IMPORTANT :
Le fichier source contient des tronçons d'itinéraires. Ce pack sélectionne 126
tronçons/itinéraires nommés réels et les exporte individuellement en GPX.
Il ne prétend pas que chaque fichier correspond exactement aux 126 intitulés
du catalogue précédent.

Fichiers :
- GPX/ : 126 fichiers GPX
- rapport.csv : métadonnées des tracés
